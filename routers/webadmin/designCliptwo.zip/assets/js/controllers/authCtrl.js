'use strict';


app.controller('authCtrllogin', ['$scope', '$compile', '$http', '$rootScope','loginService', 'managementService','$localStorage','$state', function ($scope, $compile, $http, $rootScope,loginService,managementService,$localStorage,$state) {

$localStorage.loggedIn = false;
$localStorage.userRole = null;
    //initially set those objects to null to avoid undefined error
	
	
	
	/* $scope.changeLang = function (langid) {
	
	$localStorage.langid = langid;
	
	
	$scope.language= {
				
				language : $localStorage.langid
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			
			console.log(response.Response);
			$scope.translation = {
				
				response : response.Response
			};
		
		})
	
	
	} */
	
    $scope.doLogin = function (auth) {
       var authUser = '{ "authUser" : {"username":"'+auth.username +'", "password": "'+auth.passwordw +'" }}';
		console.log(authUser);
		managementService.post($rootScope.siteURL, authUser, 'travialistAdmin/authUser' ,  function(response) {
			if(response.status=='success'){
			
				if(auth.username == 'superadmin'){
			
					$localStorage.user_id = 0;			
					$localStorage.username = auth.username;
					$localStorage.org = 'Travialist';
					$localStorage.default_lang_id = 0;
					$rootScope.user = {
							name: 'Super-Admin',
							job: 'ng-Dev',
							picture: 'app/img/user/02.jpg',
							userPreviledges: $localStorage.userPreviledges,
							org : $localStorage.org
						};
			
				}else{
					$localStorage.user_id = response.response[0].user_id;
					$localStorage.username = response.response[0].username;
					$localStorage.userRole = response.response[0].role_id;
					$localStorage.userPreviledges = [];
					$localStorage.org = response.response[0].org_name;
					$localStorage.org_id = response.response[0].org_id;
					$localStorage.default_lang_id = response.response[0].lang_id;
					
					managementService.listofpermissionsByRoleid($rootScope.siteURL, $localStorage.userRole, function(response) {
						angular.forEach(response, function(value, key) {
						  $localStorage.userPreviledges.push(value.privileges_id);
						});
					});
					
					$rootScope.user = {
							name: $localStorage.username,
							job: 'ng-Dev',
							picture: 'app/img/user/02.jpg',
							userPreviledges: $localStorage.userPreviledges,
							org : $localStorage.org
						};
					}
					$rootScope.userPreviledges = $localStorage.userPreviledges;
					$localStorage.loggedIn = true;
					$state.go('app.dashboard', {stateParamKey: '123'});
			}
			
			else{
				$scope.messageAuth = "Wrong username or password";
			}
		 
		});
		
    };
	
	
	
	
	
//	$scope.changeLang(1);
	
	
	
}]);


