angular.module('myApp', ['naif.base64'])
app.controller('poiCtrl', ['$scope', '$compile', '$http', '$rootScope','loginService', 'managementService','$localStorage',"$filter",'ngTableParams','$state','$window', function ($scope, $compile, $http, $rootScope,loginService,managementService,$localStorage,$filter,ngTableParams,$state,$window) {

	$rootScope.user = {
		name: $localStorage.username,
		job: 'ng-Dev',
		picture: 'app/img/user/02.jpg',
		userPreviledges: $localStorage.userPreviledges,
		org : $localStorage.org
	};
			
	$scope.getPoiData = function () {
		var authUser = '';
		managementService.post($rootScope.siteURL, authUser, 'poiFoursquareApp/poiFoursquare' ,  function(response) {
			console.log(response);
			if(response.status=='success'){
				console.log(response.data);
				var data = response.data;
					$scope.tableParams = new ngTableParams({
					page: 1,
					count: 10
				}, {
					total: data.length,
					getData: function ($defer, params) {
						var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
						$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
					}
				});
			}
		});
	}
	

	$scope.AddAddress= function(p,img){
			console.log(img);
			console.log(img.length);
			console.log(img[0].base64);
			var authUser = '{ "poiData" : {"poi":"'+ p +'", "image": "'+ img +'" }}';
			
			managementService.post($rootScope.siteURL, authUser, 'poiFoursquareApp/poiPointImage' ,  function(response) {
			console.log(response);
			if(response.status=='success'){
				$scope.getPoiData();
			}
		});
			
	};
  
  

  
	/* var uploadedCount = 0;

	$scope.files = []; */
	/* Image Uplade code end*/
	
	$scope.getPoiData();
	
	
	
	
	
}]);
				
			
			
app.controller('ctrl', function($scope, $http, $window, $rootScope){
	$scope.onChange = function (e, fileList) {
		alert(1234);
		console.log(fileList);
		/* alert('this is on-change handler!'); */
	};
  
	$scope.onLoad = function (e, reader, file, fileList, fileOjects, fileObj) {
		alert(12345);
		
		console.log(1);
		console.log(file);
		/* alert('this is handler for file reader onload event!'); */
	};
	
	var uploadedCount = 0;
	$scope.files = [];
});
		