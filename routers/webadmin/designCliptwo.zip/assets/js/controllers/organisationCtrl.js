'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('organisationCtrl', ["$rootScope","$scope", "$filter", "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, ngTableParams,managementService, $localStorage) {
    
$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
										
				
	$scope.changeLang = function (langid) {
	
	$localStorage.default_lang_id = langid;
	
	
	$scope.language= {
				
				language : $localStorage.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			
			console.log(response.Response);
			$rootScope.translation = {
				
				response : response.Response
				
			};
	/*	setTimeout(function(){
			////alert(55);
			$(".header").html("some title");
			
		},2000);
*/
		
		})
	
	
	}			
//alert($localStorage.default_lang_id);
	if($localStorage.default_lang_id == 0){
		
	$scope.changeLang(1);		
	
	}
	else{
		
	$scope.changeLang($localStorage.default_lang_id);			
		
	}
				
				
				
				
    $scope.editId = -1;

    $scope.setEditId = function (pid) {
        $scope.editId = pid;
    };
	
	
	$scope.updateOrg = function (p) {
       
		managementService.updateOrg($rootScope.siteURL, p,  function(response) {
			console.log(response);
			 $scope.editId = -1;
		 $scope.defaultOrglist();
		});
		
		
    };
	
	
	$scope.AddOrg = function (pn) {
       
	   if(pn==undefined){
		   
		   $scope.messageValid = "Enter Organisation Details";
		   return false;
	   }
	   else if(pn.org_name==undefined || pn.org_name==''){
		   //alert(2);
		   $scope.messageValid = "Enter Organisation Name";
		   return false;
	   }
	   else if(pn.default_lang_id==undefined || pn.default_lang_id==''){
		   
		   
		   $scope.messageValid = "Select any Language";
		   return false;
	   }
	   else if(pn.sponsor==undefined || pn.sponsor==''){
		  pn.sponsor = '';
		   
	   }
	   
	   $scope.messageValid = "";
	   
	   
		managementService.addOrg($rootScope.siteURL, pn,  function(response) {
			console.log(response);
			 
		 $scope.defaultOrglist();
		 pn.org_name="";
		 pn.default_lang_id="";
		 pn.sponsor="";
		});
		
		
    };
	
	
	$scope.defaultOrglist = function () {
        
				
		managementService.defaultData($rootScope.siteURL,  function(response) {
			
		var data = response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	
	
	$scope.getLanguages = function () {
        
				
		managementService.getLanguages($rootScope.siteURL,  function(response) {
			
		console.log(response);
		$scope.data_lang = {
      availableOptions: response.Response
   };
			/*$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});*/
					
		});
		
    };
	
	$scope.defaultOrglist();
	
	$scope.getLanguages();
	
	
}]);
