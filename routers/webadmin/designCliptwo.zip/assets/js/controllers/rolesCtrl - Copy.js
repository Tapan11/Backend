'use strict';
/**
 * controller for Messages
 */

app.controller('rolesCtrl', ["$rootScope", "$scope", "$state", "$interval", "managementService",
function($rootScope, $scope, $state, $interval, managementService) {
	

	
	
	$scope.listofroles = function() {
		managementService.listofroles($rootScope.siteURL,  function(response) {
			console.log(response);
			 $scope.data_roles = {
			availableOptions: response
		};
		})
	};
	
	/*$scope.listofpermissions = function() {
		managementService.listofpermissions($rootScope.siteURL,  function(response) {
			console.log(response);
			 $scope.data_permissions = {
			availableOptions: response
		};
		})
	};*/
	
	
	$scope.getPermissionsbyRoleId = function(role_id) {
		managementService.listofpermissionsByRoleid($rootScope.siteURL, role_id, function(response) {
			console.log(response);
			$scope.data_permissionsByRoleIdEdit = null;
			 $scope.data_permissionsByRoleId = {
			availableOptions: response
		};
		})
	};
	
	
	$scope.getPermissionsbyRoleIdEdit = function(role_id) {
		
		$scope.settingoption = role_id;
		var arr1 = [];
		var arr2 = [];
		var arr3 = [];
		var count = 0;
		$scope.data_permissionsByRoleId = null;
		managementService.listofpermissions($rootScope.siteURL,  function(response) {
			arr1 =  response;
			console.log(1);
			managementService.listofpermissionsByRoleid($rootScope.siteURL, role_id, function(response1) {
			arr2 =  response1;
			console.log(2); 
		angular.forEach(arr1, function(value1, key1) {
		angular.forEach(arr2, function(value2, key2) {
			arr3[count]=value1;
			
			if (value1.privileges_id === value2.privileges_id) {
			   arr3[count].checkedin = 1;
			  }
			  arr3[count].role_id = role_id;
			  arr3[count].value = 0;
		});
		count++;
		});
		
		if(arr3.length == arr1.length){
		console.log(arr3);	
		return $scope.data_permissionsByRoleIdEdit = {
			availableOptions: arr3
		};
		}
		})
		})
	};
	
	
	
	$scope.changePermissionbyRoleId = function(role_id,privileges_id,val) {
		/* alert(role_id);
		alert(privileges_id);*/
		alert(val); 
		/*managementService.listofpermissionsByRoleid($rootScope.siteURL, role_id, function(response) {
			console.log(response);
			$scope.data_permissionsByRoleIdEdit = null;
			 $scope.data_permissionsByRoleId = {
			availableOptions: response
		};
		})*/
	};
	
	
	
	


 $scope.SavevalidateColumns = function (role_id) {
	 
									$scope.changepermission = {
										role_id: role_id,
										previleges_id : []
									};
                            $( ".checkedpermissionlist" ).each(function( index ) {
							   if ($(this).prop('checked')) {
								   
								   $scope.changepermission.previleges_id.push(index);
								   
								}
							});
							console.log($scope.changepermission);
                           
                        };  


	
	
 	
	

	
	$scope.listofroles();
	
	//$scope.listofpermissions();
	
	
	
	
}]);
app.controller('ViewMessageCrtl', ['$scope', '$stateParams',
function($scope, $stateParams) {
	function getById(arr, id) {
		for (var d = 0, len = arr.length; d < len; d += 1) {
			if (arr[d].id == id) {

				return arr[d];
			}
		}
	}


	$scope.message = getById($scope.messages, $stateParams.inboxID);

}]);
