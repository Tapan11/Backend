'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('leisureCtrl', ["$rootScope","$scope", "$filter", "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, ngTableParams,managementService,$localStorage) {
	
	
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg'
				};
	if($localStorage.user_id == 0){
				
				$rootScope.user = {
				user_id : 0,
				type : $localStorage.type
					
				};
				
			}
			else{
					
					$rootScope.user = {
				user_id : $localStorage.user_id,
				type : $localStorage.type
					
				};
			
			}
	
    $scope.editId = -1;
	
	$scope.school_code="";$scope.generatecode = function(pn){			$('#gencode').val(Math.floor(Math.random()*89999+10000));			 $scope.school_code=$('#gencode').val();}
	
	
	$scope.AddCenters = function (pn) {
	  
		managementService.post($rootScope.siteURL, pn, 'webservices.php?action=addLeisureCenterWeb', function(response) {
			console.log(response);
			$scope.defaultUserlist();
		 
		 pn.center_name="";
		 pn.center_address="";
		 pn.center_username="";
		 pn.center_password="";
		
		
		});
		
		
    };
    
	$scope.updateLeisure = function (p) {
       	    
	  
	   
	   $scope.messageValid1 = "";
	   
	   managementService.post($rootScope.siteURL, p , 'webservices.php?action=updateLeisureCenterWeb',  function(response) {
			console.log(response);
			
		
		});
		
		
		
		 $scope.editId = -1;
    };


    $scope.setEditId = function (pid) {
		
        $scope.editId = pid;
		 $scope.viewId = -1;
		$scope.getprofileInfo = {
			userid : pid
		} 
		
		
		
		
		/* managementService.post($rootScope.siteURL, $scope.getprofileInfo, 'webservices.php?action=getSchoolinfoWeb',  function(response) {
			console.log(response.Response);
			$scope.userinfo = {
				school_name:response.Response[0].school_name,
				contact_person_name:response.Response[0].contact_person_name,
				email:response.Response[0].email,
				password:response.Response[0].password,
				phone:response.Response[0].phone,
				school_code:response.Response[0].school_code
			}
		
		});	 */
    };
	
	
	
	
	 $scope.viewId = -1;

    $scope.setViewId = function (pid) {
        $scope.viewId = pid;
		$scope.editId = -1;
		$scope.getprofileInfo = {
			userid : pid
		}
	
	managementService.post($rootScope.siteURL, $scope.getprofileInfo, 'users/getUserinfo',  function(response) {
			console.log(response.Response);
			$scope.userinfo = {
				
				fname : response.Response[0].value,
				lname : response.Response[1].value,
				contact_no : response.Response[2].value,
				address : response.Response[3].value
								
			}
			
		});
		
		
		
    };
	
	
	
	
	$scope.defaultUserlist = function () {
        
			
		managementService.get($rootScope.siteURL, 'webservices.php?action=listLeisureWeb', function(response) {
		console.log(response);	
		var data = response.Response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	
	

	
	
	
	$scope.defaultOrglist = function () {
        
				
		managementService.defaultData($rootScope.siteURL,  function(response) {
			
		$scope.data_org = {
			availableOptions: response
		};

					
		});
		
    };
	
	$scope.listofroles = function() {
		$scope.userin= {
				
				user_id : $localStorage.user_id
			}
		if($localStorage.user_id > 0){	
		managementService.post($rootScope.siteURL, $scope.userin, 'users/listOfRoles_asPerUser',  function(response) {
			console.log(response);
			 $scope.data_roles = {
			availableOptions: response
		};
		})
		}
		else{
			
			managementService.listofroles($rootScope.siteURL,  function(response) {
			console.log(response);
			 $scope.data_roles = {
			availableOptions: response
		};
		})
		}
	};
	
	
	
	$scope.defaultUserlist();
	
	
	
	
}]);
