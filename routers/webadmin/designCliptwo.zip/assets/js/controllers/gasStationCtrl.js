'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('gasStationCtrl', ["$rootScope","$scope", "$filter", '$parse', "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, $parse, ngTableParams,managementService, $localStorage) {
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
				
				
				
$scope.changeLang = function (langid) {
	$localStorage.default_lang_id = langid;
	$scope.language= {
				language : $localStorage.default_lang_id
			}
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			$rootScope.translation = {
				response : response.Response
			};
	});
}

	if($localStorage.default_lang_id == 0){
		$scope.changeLang(1);		
	}
	else{
		$scope.changeLang($localStorage.default_lang_id);			
	}
	
	$scope.gasStationList = function (user_id) {
    	$scope.data_user = {
			userid:user_id,
			org_id:$localStorage.org_id
		};		
		managementService.post($rootScope.siteURL, $scope.data_user, 'gasStation/gasStationList', function(response) {
			console.log(response);
		if(response.Response == "No Result Found")
		{
			response.Response ='';
			
		}
		var data = response.Response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	$scope.gasStationList ();
	 $scope.setEditId = function (pid) {
		$scope.editId = pid;
    };
	
	
	$scope.updateGasStation = function (p) {
        managementService.post($rootScope.siteURL, p , 'gasStation/updateGasStation' , function(response) {
			$scope.editId = -1;
		});
	};
	
	$scope.addGasStation = function(p){
		
		$scope.addGasStation= {
				org_id :$localStorage.org_id,
				gasStationInfo:p
			}
			
		managementService.post($rootScope.siteURL, $scope.addGasStation , 'gasStation/addGasStation' , function(response) {
		$scope.gasStationList($localStorage.user_id);			
		});
	};
	
	
}]);