'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('translationsCtrl', ["$rootScope","$scope", "$filter", "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, ngTableParams,managementService, $localStorage) {
    
$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
				
    $scope.editId = -1;

    $scope.setEditId = function (pid) {
        $scope.editId = pid;
    };
	
	
	
	
	
	$scope.changeLang = function (langid) {
	
	$localStorage.default_lang_id = langid;
	
	
	$scope.language= {
				
				language : $localStorage.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			
			console.log(response.Response);
			$rootScope.translation = {
				
				response : response.Response
				
			};
	})

	}			

	if($localStorage.default_lang_id == 0){
		
	$scope.changeLang(1);		
	
	}
	else{
		
	$scope.changeLang($localStorage.default_lang_id);			
		
	}			
	
	
	
	$scope.updateTranslations = function (p) {
       
	   $scope.translatingData= {
				
				default_lang_id : $scope.language.language,
				word_id : p.id,
				translations : p.translations
			}
	   
		managementService.post($rootScope.siteURL, $scope.translatingData, 'updateTranslations' ,  function(response) {
			console.log(response);
			 $scope.editId = -1;
		 //$scope.ChangeTranslations($scope.translatingData);
		});
		
		
    };
	
	
	$scope.AddOrg = function (pn) {
       
	   if(pn==undefined){
		   
		   $scope.messageValid = "Enter Organisation Details";
		   return false;
	   }
	   else if(pn.org_name==undefined || pn.org_name==''){

		   $scope.messageValid = "Enter Organisation Name";
		   return false;
	   }
	   else if(pn.default_lang_id==undefined || pn.default_lang_id==''){
		   
		   
		   $scope.messageValid = "Select any Language";
		   return false;
	   }
	   else if(pn.sponsor==undefined || pn.sponsor==''){
		  pn.sponsor = '';
		   
	   }
	   
	   $scope.messageValid = "";
	   
	   
		managementService.addOrg($rootScope.siteURL, pn,  function(response) {
			console.log(response);
			 
		 $scope.defaultOrglist();
		 pn.org_name="";
		 pn.default_lang_id="";
		 pn.sponsor="";
		});
		
		
    };
	
	
	$scope.getLanguages = function () {
        
				
		managementService.getLanguages($rootScope.siteURL,  function(response) {
			
		console.log(response);
		$scope.data_lang = {
      availableOptions: response.Response
   };
			/*$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});*/
					
		});
		
    };
	
	
	$scope.ChangeTranslations = function (pn) {
        
				
$scope.language= {
				
				language : pn.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			console.log(response);
			console.log(12121212);
			var data = response.Response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
		
		})
		
    };
	
	
	
	
	
	$scope.getLanguages();
	
	
}]);
