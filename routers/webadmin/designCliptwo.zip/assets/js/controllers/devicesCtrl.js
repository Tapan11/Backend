'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('devicesCtrl', ["$rootScope","$scope", "$filter", '$parse', "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, $parse, ngTableParams,managementService, $localStorage) {
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
				
				
				
$scope.changeLang = function (langid) {
	
	$localStorage.default_lang_id = langid;
	
	
	$scope.language= {
				
				language : $localStorage.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			
			console.log(response.Response);
			$rootScope.translation = {
				
				response : response.Response
				
			};
	})

	}			
////alert($localStorage.default_lang_id);
	if($localStorage.default_lang_id == 0){
		
	$scope.changeLang(1);		
	
	}
	else{
		
	$scope.changeLang($localStorage.default_lang_id);			
		
	}
	
	$scope.Math = window.Math;
    $scope.csv = {
    	content: null,
    	header: true,
    	headerVisible: true,
    	separator: ',',
    	separatorVisible: true,
    	result: null,
    	encoding: 'ISO-8859-1',
    	encodingVisible: true,
        uploadButtonLabel: "upload a csv file",
        progressCallback: function(progress) {
            $scope.$apply( function() {
                $scope.progress = progress;
            });
        },
        streamingCallback: function(stream) {
            if ( typeof stream != "undefined" ) {
                $scope.$apply( function() {
                    $scope.preview = stream[Math.floor(Math.random()*stream.length)];
					
                });
            }
        },
        streamingErrorCallback: function(streamError) {
            console.log(streamError);
        }
    };
	
	
	
	


    var _lastGoodResult = '';
     $scope.toPrettyJSON = function (json, tabWidth, org_id) {
		 
		 var checkHeader = $scope.csv.content;
		 checkHeader = checkHeader.split(",");
		 if(checkHeader[0]!='Serial Number'){
			$scope.messageValid2 = "Wrong CSV format!"; 
			return false;
		 }
		 else if(org_id==undefined || org_id==''){
		   $scope.messageValid2 = "Select Organisation";
		   return false;
		}
		 $scope.messageValid2 = "";
		var objStr =  JSON.stringify(json);
		var obj = null;
		try {
			
			obj = $parse(objStr)({});
			
			
		} catch(e){
			// eat $parse error
			return _lastGoodResult;
		}

		var result = JSON.stringify(obj, null, Number(tabWidth));
		_lastGoodResult = result;
		
		
		var valuesArray = [];

		for(var i=0; i<obj.length-1; i++){
	
			valuesArray.push([obj[i][0], obj[i][1], obj[i][2], obj[i][3], obj[i][4], 0, org_id]);

		}
		
		
		
		console.log(valuesArray);
		
		
		managementService.post($rootScope.siteURL, valuesArray, 'devices/addDevicesCSV', function(response) {
			console.log(response);
			if(response.Insert == 'Failure'){
				
			swal("Error!", "First create an Organisation Head!");	
				
			}
			
			if(response.Insert == 'Failed'){
				
			$scope.messageValid2 = "Please check the duplicate entries!";	
				
			}
			$scope.defaultDevicelist();
		 
		 

		});
		
		
		
    };
	
    $scope.editId = -1;
	
	$scope.AddDevice = function (pn) {
       
	   if(pn==undefined){
		   
		   $scope.messageValid = "Enter Device Details";
		   return false;
	   }
	   else if(pn.serial_number==undefined || pn.serial_number==''){
		 
		   $scope.messageValid = "Enter Serial Number";
		   return false;
	   }
	   else if(pn.full_id==undefined || pn.full_id==''){
		 
		   $scope.messageValid = "Enter Full ID";
		   return false;
	   }
	   else if(pn.device_ssid==undefined || pn.device_ssid==''){
		   
		   
		   $scope.messageValid = "Enter Device SSID";
		   return false;
	   }
	   else if(pn.device_password==undefined || pn.device_password==''){
		   $scope.messageValid = "Enter Device Password";
		   return false;
		   
	   }
	   else if(pn.active==undefined || pn.active==''){
		   $scope.messageValid = "Select device status to Active or Inactive";
		   return false;
		   
	   }
	   else if(pn.org_id==undefined || pn.org_id==''){
		   $scope.messageValid = "Select Organisation";
		   return false;
		   
	   }
	   
	   
	   $scope.messageValid = "";
	   managementService.post($rootScope.siteURL, pn, 'devices/addDevice', function(response) {
		   console.log(response);
			if(response.Insert == 'Failure'){
				
				swal("Error!", "First create an Organisation Head!");
				
			}
			$scope.defaultDevicelist();
		 
		 pn.serial_number="";
		 pn.full_id="";
		 pn.device_ssid="";
		 pn.device_password="";
		 pn.active="";
		 pn.access_token="";
		 pn.org_id="";

		});
    };
    

	$scope.updateDevice = function (p) {
		

		 if(p==undefined){
		   
		   $scope.messageValid1 = "Enter Device Details";
		   return false;
	   }
	   else if(p.serial_number==undefined || p.serial_number==''){
		 
		   $scope.messageValid1 = "Enter Serial Number";
		   return false;
	   }
	   else if(p.full_id==undefined || p.full_id==''){
		 
		   $scope.messageValid1 = "Enter Full ID";
		   return false;
	   }
	   else if(p.device_ssid==undefined || p.device_ssid==''){
		   
		   
		   $scope.messageValid1 = "Enter Device SSID";
		   return false;
	   }
	   else if(p.device_password==undefined || p.device_password==''){
		   $scope.messageValid1 = "Enter Device Password";
		   return false;
		   
	   }
	   else if(p.active==undefined || p.active===''){
		   $scope.messageValid1 = "Select device status to Active or Inactive";
		   return false;
		   
	   }
	   else if(p.org_id==undefined || p.org_id==''){
		   $scope.messageValid1 = "Select Organisation";
		   return false;
		   
	   }
		
		$scope.messageValid = "";
       
		$scope.updateDevicedata = [];
		$scope.updateDevicedata.push(p);
		var orgDetails = $filter('filter')($scope.data_org.availableOptions, { org_name: p.org_name });
		$scope.updateDevicedata[0].new_org_id=orgDetails[0].org_id;

		managementService.post($rootScope.siteURL, $scope.updateDevicedata, 'devices/updateDevicedata',  function(response) {
			console.log(response);		
		});
		
		$scope.editId = -1;
    };


    $scope.setEditId = function (pid) {
		
        $scope.editId = pid;
    };
	

	$scope.defaultDevicelist = function () {
        
				
		managementService.get($rootScope.siteURL, 'devices/getDeviceList', function(response) {
			
		var data = response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	
	
	
	$scope.defaultOrglist = function () {
        
				
		managementService.defaultData($rootScope.siteURL,  function(response) {
			
		$scope.data_org = {
			availableOptions: response
		};

					
		});
		
    };
	

	
	
	$scope.defaultDevicelist();
	

	
	$scope.defaultOrglist();
	

	
	
}]);
app.controller('devicesAssigningCtrl', ["$rootScope","$scope", "$filter", '$parse', "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, $parse, ngTableParams,managementService, $localStorage) {
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
	
	
	$scope.changeLang = function (langid) {
	
	$localStorage.default_lang_id = langid;
	
	
	$scope.language= {
				
				language : $localStorage.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			
			console.log(response.Response);
			$rootScope.translation = {
				
				response : response.Response
				
			};
	})

	}			
//alert($localStorage.default_lang_id);
	if($localStorage.default_lang_id == 0){
		
	$scope.changeLang(1);		
	
	}
	else{
		
	$scope.changeLang($localStorage.default_lang_id);			
		
	}
	
	$scope.Math = window.Math;
    $scope.csv = {
    	content: null,
    	header: true,
    	headerVisible: true,
    	separator: ',',
    	separatorVisible: true,
    	result: null,
    	encoding: 'ISO-8859-1',
    	encodingVisible: true,
        uploadButtonLabel: "upload a csv file",
        progressCallback: function(progress) {
            $scope.$apply( function() {
                $scope.progress = progress;
            });
        },
        streamingCallback: function(stream) {
            if ( typeof stream != "undefined" ) {
                $scope.$apply( function() {
                    $scope.preview = stream[Math.floor(Math.random()*stream.length)];
					
                });
            }
        },
        streamingErrorCallback: function(streamError) {
            console.log(streamError);
        }
    };
	
	
	
	


    var _lastGoodResult = '';
     $scope.toPrettyJSON = function (json, tabWidth, org_id) {
		 
		 var checkHeader = $scope.csv.content;
		 checkHeader = checkHeader.split(",");
		 if(checkHeader[0]!='Serial Number'){
			$scope.messageValid2 = "Wrong CSV format!"; 
			return false;
		 }
		 else if(org_id==undefined || org_id==''){
		   $scope.messageValid2 = "Select Organisation";
		   return false;
		}
		 $scope.messageValid2 = "";
		var objStr =  JSON.stringify(json);
		var obj = null;
		try {
			
			obj = $parse(objStr)({});
			
			
		} catch(e){
			// eat $parse error
			return _lastGoodResult;
		}

		var result = JSON.stringify(obj, null, Number(tabWidth));
		_lastGoodResult = result;
		
		
		var valuesArray = [];

		for(var i=0; i<obj.length-1; i++){
	
			valuesArray.push([obj[i][0], obj[i][1], obj[i][2], obj[i][3], obj[i][4], 0, org_id]);

		}
		
		
		
		console.log(valuesArray);
		
		
		managementService.post($rootScope.siteURL, valuesArray, 'devices/addDevicesCSV', function(response) {
			console.log(response);
			if(response.Insert == 'Failed'){
				
			$scope.messageValid2 = "Please check the duplicate entries!";	
				
			}
			$scope.defaultDevicelist();
		 
		 

		});
		
		
		
    };
	
    $scope.editId = -1;
	
	$scope.AddDevice = function (pn) {
       
	   if(pn==undefined){
		   
		   $scope.messageValid = "Enter Device Details";
		   return false;
	   }
	   else if(pn.serial_number==undefined || pn.serial_number==''){
		 
		   $scope.messageValid = "Enter Serial Number";
		   return false;
	   }
	   else if(pn.full_id==undefined || pn.full_id==''){
		 
		   $scope.messageValid = "Enter Full ID";
		   return false;
	   }
	   else if(pn.device_ssid==undefined || pn.device_ssid==''){
		   
		   
		   $scope.messageValid = "Enter Device SSID";
		   return false;
	   }
	   else if(pn.device_password==undefined || pn.device_password==''){
		   $scope.messageValid = "Enter Device Password";
		   return false;
		   
	   }
	   else if(pn.active==undefined || pn.active==''){
		   $scope.messageValid = "Select device status to Active or Inactive";
		   return false;
		   
	   }
	   else if(pn.org_id==undefined || pn.org_id==''){
		   $scope.messageValid = "Select Organisation";
		   return false;
		   
	   }
	   
	   
	   $scope.messageValid = "";
	   managementService.post($rootScope.siteURL, pn, 'devices/addDevice', function(response) {
			//console.log(response);
			$scope.defaultDevicelist();
		 
		 pn.serial_number="";
		 pn.full_id="";
		 pn.device_ssid="";
		 pn.device_password="";
		 pn.active="";
		 pn.access_token="";
		 pn.org_id="";

		});
    };
    

	$scope.updateDevice = function (p) {
		

		 if(p==undefined){
		   
		   $scope.messageValid1 = "Enter Device Details";
		   return false;
	   }
	   else if(p.serial_number==undefined || p.serial_number==''){
		 
		   $scope.messageValid1 = "Enter Serial Number";
		   return false;
	   }
	   else if(p.full_id==undefined || p.full_id==''){
		 
		   $scope.messageValid1 = "Enter Full ID";
		   return false;
	   }
	   else if(p.device_ssid==undefined || p.device_ssid==''){
		   
		   
		   $scope.messageValid1 = "Enter Device SSID";
		   return false;
	   }
	   else if(p.device_password==undefined || p.device_password==''){
		   $scope.messageValid1 = "Enter Device Password";
		   return false;
		   
	   }
	   else if(p.active==undefined || p.active===''){
		   $scope.messageValid1 = "Select device status to Active or Inactive";
		   return false;
		   
	   }
	   else if(p.org_id==undefined || p.org_id==''){
		   $scope.messageValid1 = "Select Organisation";
		   return false;
		   
	   }
		
		$scope.messageValid = "";
       
		$scope.updateDevicedata = [];
		$scope.updateDevicedata.push(p);
		var orgDetails = $filter('filter')($scope.data_org.availableOptions, { org_name: p.org_name });
		$scope.updateDevicedata[0].new_org_id=orgDetails[0].org_id;

		managementService.post($rootScope.siteURL, $scope.updateDevicedata, 'devices/updateDevicedata',  function(response) {
			console.log(response);		
		});
		
		$scope.editId = -1;
    };


    $scope.setEditId = function (pid) {
		
        $scope.editId = pid;
    };
	

	$scope.defaultDevicelist = function () {
       
		$scope.data_user = {
			userid: $localStorage.user_id
		};		
		managementService.post($rootScope.siteURL, $scope.data_user, 'devices/getDeviceList', function(response) {
			console.log(response);
		var data = response.Response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	
	
	
	$scope.defaultOrglist = function () {
        
				
		managementService.defaultData($rootScope.siteURL,  function(response) {
			
			
		$scope.data_org = {
			availableOptions: response
		};

					
		});
		
    };
	
	
	
	
	$scope.assignTo = function (p) {
        
				
		managementService.p($rootScope.siteURL,  function(response) {
			
		$scope.data_org = {
			availableOptions: response
		};

					
		});
		
    };
	
	
	$scope.defaultDevicelist();
	

	

	

	
	
}]);



app.controller('mydevicesCtrl', ["$rootScope","$scope", "$filter", '$parse', "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, $parse, ngTableParams,managementService, $localStorage) {
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
	
	$scope.my = { message: false };
	
	
	$scope.changeLang = function (langid) {
	
	$localStorage.default_lang_id = langid;
	
	
	$scope.language= {
				
				language : $localStorage.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			
			
			
			$rootScope.translation = {
				
				response : response.Response
				
			};
	})

	}			

	if($localStorage.default_lang_id == 0){
		
	$scope.changeLang(1);		
	
	}
	else{
		
	$scope.changeLang($localStorage.default_lang_id);			
		
	}
	

    $scope.editId = -1;
	
	

    $scope.setEditId = function (pid) {
		
	
		//alert(pid);
        $scope.editId = pid;
    };
	
	
	
	
	var data;

  $scope.optionToggled = function(){
	  
    $scope.isAllSelected = data.every(function(itm){ return itm.selected; })
  }
	
	
	$scope.defaultDevicelist = function () {
        
		$scope.data_user = {
			userid: $localStorage.user_id
		};		
		managementService.post($rootScope.siteURL, $scope.data_user, 'devices/getDeviceList', function(response) {
			console.log(response);
			
			
			$scope.data_permissionsByRoleId1 = {
				availableOptions: [],
				
			};
		
			if(response.Response == "No Result Found")
		{
			 $scope.my = { message: true };
			response.Response ='';
			
		}else{
			$scope.my = { message: false };
			
		}
		 data = response.Response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	
	
	

	$scope.getChildUsers = function () {
       
		$scope.data_user = {
			userid: $localStorage.user_id
		};		
		managementService.post($rootScope.siteURL, $scope.data_user, 'devices/getChildUsersWithDevices', function(response) {
			$scope.data_ChildUsers = {
			availableOptions: response.Response
		};
					
		});
		
    };
	
	
	$scope.assignTo = function (p) {
        
			
		$scope.assignTodata = {
			availableOptions: $scope.data_permissionsByRoleId1.availableOptions,
			assign_id : p.assign_id
		};
		
		managementService.post($rootScope.siteURL, $scope.assignTodata , 'devices/updateAssignDevice' , function(response) {
			console.log(response);
			$scope.defaultDevicelist();
		/*$scope.data_org = {
			availableOptions: response
		};*/

			location.reload();

		
		});
		
    };
	
	
	$scope.defaultDevicelist();
		$scope.getChildUsers();

		
		
	

	$scope.selectall =  0;
	$scope.toggleAll = function () {
		////alert($scope.selectall);
		
		
			$scope.data_permissionsByRoleId1 = {
				availableOptions: [],
				
			};
		
		if($scope.selectall == 0){
			$scope.selectall = 1;
			angular.forEach(data, function(value, key) {
				
				value.checked = true;
			  $scope.data_permissionsByRoleId1.availableOptions.push(value);
			});
		}else{
			
			$scope.selectall = 0;
			
		}
		
		
		
		
		console.log($scope.data_permissionsByRoleId1.availableOptions);
    };
	
	
	
	
	
		$scope.toggleSelection = function toggleSelection(message) {
		console.log(message);
		if(message.checked){
			message.checked = false;
			$scope.data_permissionsByRoleId1.availableOptions.filter(function(item, i){
				if(message.device_id == item.device_id){
					$scope.data_permissionsByRoleId1.availableOptions.splice(i, 1);
				}	
			})
		} else {
			message.checked = true;
			$scope.data_permissionsByRoleId1.availableOptions.push(message);
		}
		
	console.log($scope.data_permissionsByRoleId1.availableOptions);
  };
	
	

}]);




app.controller('myChildUsersWithDevices', ["$rootScope","$scope", "$filter", '$parse', "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, $parse, ngTableParams,managementService, $localStorage) {
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
	
	$scope.my = { message: false };
	$scope.dev = { message: false };
	
	if(!$localStorage.parent_user){
		
	$scope.parent_user = $rootScope.user.name;	
	}
	else{
		
	$scope.parent_user = $localStorage.parent_user;	
	}
	
	
	$scope.changeLang = function (langid) {
	
	$localStorage.default_lang_id = langid;
	
	
	$scope.language= {
				
				language : $localStorage.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			
			console.log(response.Response);
			$rootScope.translation = {
				
				response : response.Response
				
			};
	})

	}			

	if($localStorage.default_lang_id == 0){
		
	$scope.changeLang(1);		
	
	}
	else{
		
	$scope.changeLang($localStorage.default_lang_id);			
		
	}
	

	
    $scope.editId = -1;


    $scope.setEditId = function (pid) {
		
        $scope.editId = pid;
    };
	

	

	$scope.defaultDevicelist = function (uid) {
       
		$scope.data_user = {
			userid: uid
		};		
		managementService.post($rootScope.siteURL, $scope.data_user, 'devices/getChildUsersWithDevices', function(response) {
			console.log(response);
		if(response.Response == "No Result Found")
		{
			 $scope.my = { message: true };
			response.Response ='';
			
		}else{
			$scope.my = { message: false };
			
		}
		var data = response.Response;
		
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	
	
	
	
	$scope.childDefaultDevicelist = function (user_id) {
       
		$scope.data_user = {
			userid: user_id
		};		
		managementService.post($rootScope.siteURL, $scope.data_user, 'devices/getDeviceList', function(response) {
			console.log(response);
			if(response.Response == "No Result Found")
		{
			 $scope.dev = { message: true };
			response.Response ='';
			
		}else{
			$scope.dev = { message: false };
			
		}
		var data = response.Response;
			$scope.tableParams1 = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	
	

	
	$scope.assignTo = function (p) {
        
				
		managementService.p($rootScope.siteURL,  function(response) {
			
		$scope.data_org = {
			availableOptions: response
		};

					
		});
		
    };


	$scope.listofChildUsers = function (p) {
        
				
		console.log(p);
		$localStorage.parent_user = p.username;
		$scope.parent_user = $localStorage.parent_user;
		
		$scope.defaultDevicelist(p.user_id);
		$scope.childDefaultDevicelist(p.user_id);
		
    };
	
	
	$scope.reSetToTop = function () {
        
				
		
		$localStorage.parent_user = $rootScope.user.name;
		$scope.parent_user = $localStorage.parent_user;
		
		$scope.defaultDevicelist($localStorage.user_id);
		$scope.childDefaultDevicelist(0);
    };
	
	$scope.defaultDevicelist($localStorage.user_id);
	$scope.reSetToTop();
	
	
}]);