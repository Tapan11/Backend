'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('rewardsCtrl', ["$rootScope","$scope", "$filter", "ngTableParams","managementService","SweetAlert", "$localStorage", function ($rootScope , $scope, $filter, ngTableParams,managementService,SweetAlert,$localStorage) {
	
	
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg'
				};
	if($localStorage.user_id == 0){
				
				$rootScope.user = {
				user_id : 0,
				type : $localStorage.type
					
				};
				
			}
			else{
					
					$rootScope.user = {
				user_id : $localStorage.user_id,
				type : $localStorage.type
					
				};
			
			}
	
    $scope.editId = -1;
	
	$scope.rewards_code="";
	$scope.generatecode = function(pn){
		$('#gencode').val(Math.floor(Math.random()*89999+10000));	
		$scope.rewards_code=$('#gencode').val();
		}
	
	
	$scope.AddRewards = function (pn) {
		
		
		if(pn==undefined){
		   SweetAlert.swal({
			 title: "Reward!",
			 text: "Enter reward name.",
			 imageUrl: "http:://oitozero.com/avatar/avatar.jpg" });
			 return;
		}
  
  if(pn.reward_name==""){
   SweetAlert.swal({
     title: "Reward!",
     text: "Enter reward name.",
     imageUrl: "http:://oitozero.com/avatar/avatar.jpg" });
     return;
  }else if(pn.points_deduction== '' || pn.points_deduction==undefined){
   SweetAlert.swal({
     title: "Points!",
     text: "Enter points deduction.",
     imageUrl: "http:://oitozero.com/avatar/avatar.jpg" });
     return;
  }else if(pn.code== '' || pn.code ==undefined){
	  SweetAlert.swal({
     title: "Code!",
     text: "Reward code should not be blank.",
     imageUrl: "http:://oitozero.com/avatar/avatar.jpg" });
     return;
  }
		
	
	   pn.leisure = $localStorage.user_id;	
	  pn.code =  $scope.rewards_code;
	  	
		managementService.post($rootScope.siteURL, pn, 'webservices.php?action=AddRewardsWeb', function(response) {
			console.log(response);
			$scope.defaultUserlist();
		 
		 pn.reward_name="";
		 pn.points_deduction="";
		 pn.code="";
		
		
		
		});
		
		
    };
    
	$scope.updateRewards = function (pn) {
       	    
	   	
		if(pn==undefined){
   SweetAlert.swal({
     title: "Reward!",
     text: "Enter reward name.",
     imageUrl: "http:://oitozero.com/avatar/avatar.jpg" });
     return;
  }
  
  if(pn.reward_name==""){
   SweetAlert.swal({
     title: "Reward!",
     text: "Enter reward name.",
     imageUrl: "http:://oitozero.com/avatar/avatar.jpg" });
     return;
  }else if(pn.points_deduction== ''){
   SweetAlert.swal({
     title: "Points!",
     text: "Enter points deduction.",
     imageUrl: "http:://oitozero.com/avatar/avatar.jpg" });
     return;
  }else if(pn.code== ''){
	  SweetAlert.swal({
     title: "Code!",
     text: "Reward code should not be blank.",
     imageUrl: "http:://oitozero.com/avatar/avatar.jpg" });
     return;
  }
	   
	   
	   
	   
	   
	   $scope.messageValid1 = "";
	   
	   managementService.post($rootScope.siteURL, pn , 'webservices.php?action=updateRewardsinfoWeb',  function(response) {
			console.log(response);
			
		
		});
		
		
		
		 $scope.editId = -1;
    };


    $scope.setEditId = function (pid) {
		
        $scope.editId = pid;
		 $scope.viewId = -1;
		$scope.getprofileInfo = {
			userid : pid
		} 
		
		
		
		
		/* managementService.post($rootScope.siteURL, $scope.getprofileInfo, 'webservices.php?action=getSchoolinfoWeb',  function(response) {
			console.log(response.Response);
			$scope.userinfo = {
				school_name:response.Response[0].school_name,
				contact_person_name:response.Response[0].contact_person_name,
				email:response.Response[0].email,
				password:response.Response[0].password,
				phone:response.Response[0].phone,
				school_code:response.Response[0].school_code
			}
		
		});	 */
    };
	
	
	
	
	 $scope.viewId = -1;

    $scope.setViewId = function (pid) {
        $scope.viewId = pid;
		$scope.editId = -1;
		$scope.getprofileInfo = {
			userid : pid
		}
	
	managementService.post($rootScope.siteURL, $scope.getprofileInfo, 'users/getUserinfo',  function(response) {
			console.log(response.Response);
			$scope.userinfo = {
				
				fname : response.Response[0].value,
				lname : response.Response[1].value,
				contact_no : response.Response[2].value,
				address : response.Response[3].value
								
			}
			
		});
		
		
		
    };
	
	
	
	
	$scope.defaultUserlist = function () {
		
        $scope.getprofileInfo = {
			userid : $localStorage.user_id
		}
			
		managementService.post($rootScope.siteURL,$scope.getprofileInfo, 'webservices.php?action=listRewardsWeb', function(response) {
		console.log(response);	
		var data = response.Response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	
	

	
	
	
	$scope.defaultOrglist = function () {
        
				
		managementService.defaultData($rootScope.siteURL,  function(response) {
			
		$scope.data_org = {
			availableOptions: response
		};

					
		});
		
    };
	
	$scope.listofroles = function() {
		$scope.userin= {
				
				user_id : $localStorage.user_id
			}
		if($localStorage.user_id > 0){	
		managementService.post($rootScope.siteURL, $scope.userin, 'users/listOfRoles_asPerUser',  function(response) {
			console.log(response);
			 $scope.data_roles = {
			availableOptions: response
		};
		})
		}
		else{
			
			managementService.listofroles($rootScope.siteURL,  function(response) {
			console.log(response);
			 $scope.data_roles = {
			availableOptions: response
		};
		})
		}
	};
	
	
	
	$scope.defaultUserlist();
	
	
	
	
}]);
