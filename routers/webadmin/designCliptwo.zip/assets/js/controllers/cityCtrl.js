angular.module('myApp', ['naif.base64'])
app.controller('cityCtrl', ['$scope', '$compile', '$http', '$rootScope','loginService', 'managementService','$localStorage',"$filter",'ngTableParams','$state','$window', function ($scope, $compile, $http, $rootScope,loginService,managementService,$localStorage,$filter,ngTableParams,$state,$window) {

	$rootScope.user = {
		name: $localStorage.username,
		job: 'ng-Dev',
		picture: 'app/img/user/02.jpg',
		userPreviledges: $localStorage.userPreviledges,
		org : $localStorage.org
	};
	
	$scope.countryData = '';
	
	
	$scope.getPoiData = function () {
		var authUser = '';
		managementService.post($rootScope.siteURL, authUser, 'poiFoursquareApp/countryList' ,  function(response) {
			console.log(response);
			if(response.status=='success'){
				console.log(response.data);
				var data = response.data;
				$scope.countryData = response.data;
					$scope.tableParams = new ngTableParams({
					page: 1,
					count: 10
				}, {
					total: data.length,
					getData: function ($defer, params) {
						var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
						$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
					}
				});
			}
		});
	}
	

	$scope.AddAddress= function(p,img){
			$scope.authUser ='';
			
			
			var arr1 = [];
			var obj1={};
			for(var i =0; i < img.length; i++){
				obj1.imgs=img[i].base64;
				console.log(img[i].base64);
				arr1.push(obj1);
				
			}
			
			//var authUser = '{ "poiData" : {"poi":"'+ p +'", "image": "'+ arr1 +'" }}';
			var authUser = {
				"poi" : p,
				"imgs" : img
				
			};
			console.log(authUser);
			
				managementService.post($rootScope.siteURL, authUser, 'poiFoursquareApp/cityPointImage' ,  function(response) {
				console.log(response);
					if(response.status=='success'){
						$scope.getPoiData();
					}
				});
			
			
	};
  
  

  
	/* var uploadedCount = 0;

	$scope.files = []; */
	/* Image Uplade code end*/
	
	$scope.getPoiData();
	
	
	
	
	
}]);
				
			
			
app.controller('ctrl', function($scope, $http, $window, $rootScope){
	$scope.onChange = function (e, fileList) {
		alert(1234);
		console.log(fileList);
		/* alert('this is on-change handler!'); */
	};
  
	$scope.onLoad = function (e, reader, file, fileList, fileOjects, fileObj) {
		alert(12345);
		
		console.log(1);
		console.log(file);
		/* alert('this is handler for file reader onload event!'); */
	};
	
	var uploadedCount = 0;
	$scope.files = [];
});
		