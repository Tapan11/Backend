'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('settingsCtrl', ["$rootScope","$scope", "$filter", "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, ngTableParams,managementService, $localStorage) {
    
$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
										


	$scope.changeLang = function (langid) {
	
	$localStorage.default_lang_id = langid;
	
	
	$scope.language= {
				
				language : $localStorage.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			console.log(response.Response);
			$rootScope.translation = {				
				response : response.Response			
			};
		})
	
	
	}	

$scope.updateLang = function (langid) {
	if(langid != undefined)
	
	{
	$scope.updateLanguage= {
				
				language : langid,
				user_id : $localStorage.user_id
			}
managementService.post($rootScope.siteURL, $scope.updateLanguage , 'users/updateLanguage' , function(response) {
			console.log(response);
			
			
			$scope.changeLang(langid);
			
		})
		
	}
}

	

	if($localStorage.default_lang_id == 0){
		
	$scope.changeLang(1);		
	
	}
	else{
		
	$scope.changeLang($localStorage.default_lang_id);			
		
	}


										
$scope.getLanguages = function () {
        
				
		managementService.getLanguages($rootScope.siteURL,  function(response) {
			
		console.log(response);
		$scope.data_lang = {
      availableOptions: response.Response
   };
   });
		
    };
	$scope.getLanguages();
	
}]);
