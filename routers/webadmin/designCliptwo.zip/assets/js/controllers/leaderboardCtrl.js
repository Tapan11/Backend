'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('leaderboardCtrl', ["$rootScope","$scope", "$filter", "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, ngTableParams,managementService,$localStorage) {
	
	
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg'
				};
	
	

	
	
	
	$scope.defaultTopTenSchoolWeb = function () {
		var user_id =$localStorage.user_id;
		
		managementService.post($rootScope.siteURL,user_id, 'webservices.php?action=topTenSchoolWeb', function(response) {
		console.log(response);	
		var data = response.Response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
			
			

			 
        })
		
		  
		
	}
	

		if($localStorage.user_id == 0){
				$rootScope.user = {
					user_id : 0,
				type : $localStorage.type
				};
				
		}
		else{
				$rootScope.user = {
					user_id : $localStorage.user_id,
				type : $localStorage.type
				};
			
				
				$scope.defaultTopTenSchoolWeb();
			}
	
	
	
}]);
