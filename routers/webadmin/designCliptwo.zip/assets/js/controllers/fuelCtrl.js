'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('fuelCtrl', ["$rootScope","$scope", "$filter", '$parse', "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, $parse, ngTableParams,managementService, $localStorage) {
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
				
	$scope.userRole = $localStorage.userRole;			
				
$scope.changeLang = function (langid) {
	$localStorage.default_lang_id = langid;
	$scope.language= {
				language : $localStorage.default_lang_id
			}
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			$rootScope.translation = {
				response : response.Response
			};
	});
}

	if($localStorage.default_lang_id == 0){
		$scope.changeLang(1);		
	}
	else{
		$scope.changeLang($localStorage.default_lang_id);			
	}
	/*
	
	$scope.listofAddedQuota = function (user_id) {
    	$scope.listofAddedQuota = {
			userid:user_id
		};		
		managementService.post($rootScope.siteURL, $scope.listofAddedQuota, 'fuel/listofAddedQuota', function(response) {
			console.log(response);
		if(response.Response == "No Result Found")
		{
			response.Response ='';
			
		}
		var data = response.Response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	$scope.listofAddedQuota ($localStorage.user_id);
	
	*/
	$scope.availableFuel = function(user_id) {
		
		
		$scope.userinfo = {
			userid:user_id
		};	
		
		
        managementService.post($rootScope.siteURL, $scope.userinfo , 'fuel/availableFuel' , function(response) {
			console.log(response);
			
			$scope.totalAvailable  = response.totalAvailable
			
			
		});
	};
	
	$scope.availableFuel($localStorage.user_id);
	
	
	
	
	$scope.userlistfor_assinging = function (user_id) {
		
		
		$scope.userinfo = {
			user_id:user_id
		};	
		
		
        managementService.post($rootScope.siteURL, $scope.userinfo , 'users/userlistfor_assinging' , function(response) {
			$scope.userlistfor_assinging = response;
			
			
			
			
		});
	};
	
	$scope.userlistfor_assinging($localStorage.user_id);
	
	
	$scope.tanklistfor_assinging = function (user_id) {
		
		
		$scope.userinfo = {
			userid:user_id
		};	
		
		
        managementService.post($rootScope.siteURL, $scope.userinfo , 'tanks/getTankList' , function(response) {
			console.log(response);
			$scope.tanklistfor_assinging = response.Response;
			
			
			
			
		});
	};
	
	$scope.tanklistfor_assinging($localStorage.user_id);
	
	
	 $scope.setEditId = function (p) {
		
		
		if(p==undefined){
			swal("Error!", "Please fill the fields!");
				return false;
		}
		else if(!p.username || !p.fuel_quantity){
			
			swal("Error!", "Please fill the fields!");
				return false;
		}
		else if($scope.totalAvailable < p.fuel_quantity)
		{
			swal("Error!", "Please enter correct quantity!");
				return false;
	
		}
		
		$scope.assignInfo = {
			sender:$localStorage.user_id,
			receiver:p.username,
			fuel_quantity:p.fuel_quantity
		};
		
		p.fuel_quantity = '';
		 managementService.post($rootScope.siteURL, $scope.assignInfo , 'fuel/assignFuel' , function(response) {
			$scope.editId = -1;
			
			
			$scope.availableFuel($localStorage.user_id);
			
			
		});
		
		
    };
	
	
	
	$scope.assigntoTank = function (p) {
		
		console.log(p);
		if(p==undefined){
			swal("Error!", "Please fill the fields!");
				return false;
		}
		else if(!p.tank_name || !p.fuel_quantity){
			
			swal("Error!", "Please fill the fields!");
				return false;
		}
		else if($scope.totalAvailable < p.fuel_quantity)
		{
			swal("Error!", "Please enter correct quantity!");
				return false;
	
		}
	
		$scope.assignInfo = {
			user_id:$localStorage.user_id,
			tank_id:p.tank_name,
			fuel_quantity:p.fuel_quantity
		};
		
		p.fuel_quantity = '';
		 managementService.post($rootScope.siteURL, $scope.assignInfo , 'fuel/assignFueltoTank' , function(response) {
			$scope.editId = -1;
			
			
			$scope.availableFuel($localStorage.user_id);
			
			
		});
		
		
    };
	
	
	
	$scope.showdivfor = function (p) {
		
		$scope.my = {
			showdivfor_users : p
		};
		console.log($scope.my.showdivfor_users);
	}
	
	
	
	$scope.addFuelQuota1 = function(p){
		
		if(p==undefined){
			swal("Error!", "Please fill the quantity!");
				return false;
		}else if(p.fuel_quantity==''){
			swal("Error!", "Please fill the quantity!");
				return false;
		}
		$scope.addFuelQuota= {
				org_id :$localStorage.org_id,
				user_id:$localStorage.user_id,
				quantity : p.fuel_quantity
			}
		p.fuel_quantity = "";	
		managementService.post($rootScope.siteURL, $scope.addFuelQuota , 'fuel/addFuelQuota' , function(response) {
		console.log(response);	
		$scope.availableFuel($localStorage.user_id);		
		});
	};
	
	
}]);