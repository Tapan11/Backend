angular.module('myApp', ['naif.base64'])


	  
	  
app.controller('featureCtrl', ['$scope', '$compile', '$http', '$rootScope','loginService', 'managementService','$localStorage',"$filter",'ngTableParams','$state','$window', function ($scope, $compile, $http, $rootScope,loginService,managementService,$localStorage,$filter,ngTableParams,$state,$window) {

	$rootScope.user = {
		name: $localStorage.username,
		job: 'ng-Dev',
		picture: 'app/img/user/02.jpg',
		userPreviledges: $localStorage.userPreviledges,
		org : $localStorage.org
	};
	
	$scope.countryData = '';
	
	
	
	
	
	
	
	$scope.getPoiData = function () {
		var authUser = '';
		managementService.post($rootScope.siteURL, authUser, 'poiFoursquareApp/countryList' ,  function(response) {
			console.log(response);
			if(response.status=='success'){
				/* console.log(response.data); */
				var data = response.data;
				$scope.countryData = response.data;
					$scope.tableParams = new ngTableParams({
					page: 1,
					count: 10
				}, {
					total: data.length,
					getData: function ($defer, params) {
						var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
						$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
					}
				});
			}
		});
	}
	

	$scope.AddAddress= function(p,img){
			$scope.authUser ='';
			var arr1 = [];
			var obj1={};
			for(var i =0; i < img.length; i++){
				obj1.imgs=img[i].base64;
				console.log(img[i].base64);
				arr1.push(obj1);
				
			}
			
			//var authUser = '{ "poiData" : {"poi":"'+ p +'", "image": "'+ arr1 +'" }}';
			var authUser = {
				"poi" : p,
				"imgs" : img
				
			};
			console.log(authUser);
			
				managementService.post($rootScope.siteURL, authUser, 'poiFoursquareApp/cityPointImage' ,  function(response) {
				console.log(response);
					if(response.status=='success'){
						$scope.getPoiData();
					}
				});
			
			
	};
  
  
  $scope.continetsChange = function(peopleAsync){
	
	 var authUser = '{ "authUser" : {"region":"'+peopleAsync.region +'"}}';
	 managementService.post($rootScope.siteURL,authUser, 'poiAddfeature/showContinentsCountry' ,  function(response) {
		console.log(response);
			if(response.status=='success'){
				console.log(response.data);
				$scope.Country  = response.data;
			}
		});
  }
  
  
  
  
	$scope.countrynameChange = function(Countryname){
	
	 var authUser = '{ "authUser" : {"countyname":"'+Countryname.name +'"}}';
	 managementService.post($rootScope.siteURL,authUser, 'poiAddfeature/showCountryCity' ,  function(response) {
			if(response.status=='success'){
				console.log(response.data);
				$scope.Cityname  = response.data;
				$scope.showAllCategory();
			}
		});
	}
  
  
	$scope.showAllCategory = function(Countryname){
		var authUser = '';
		managementService.post($rootScope.siteURL,authUser, 'poiAddfeature/showAllCategory' ,  function(response) {
			if(response.status=='success'){
				console.log(response.data);
				$scope.CategoryArray  = response.data;
			}
		});
	}
	
	
	$scope.CategoryName =function(CategoryName){
		var authUser = '{ "authUser" : {"Category":"'+CategoryName.Category +'"}}';
		managementService.post($rootScope.siteURL,authUser, 'poiAddfeature/showCategorySub' ,  function(response) {
			if(response.status=='success'){
				console.log(response.data);
				$scope.subCategoryArray  = response.data;
			}
		});
	}
  
  
  
	$scope.SubCategoryName =function(subCategory){
		var authUser = '{ "authUser" : {"subCategory":"'+subCategory.subCategory +'"}}';
		managementService.post($rootScope.siteURL,authUser, 'poiAddfeature/showCategorySubSub' ,  function(response) {
			if(response.status=='success'){
				console.log(response.data);
				$scope.subSubCategoryArray  = response.data;
			}
		});
	}
  
  

$scope.ContinentsShow= function(){
	var authUser = '';
	managementService.post($rootScope.siteURL,authUser, 'poiAddfeature/showContinents' ,  function(response) {
		console.log(123123);
		console.log(response);
			if(response.status=='success'){
				console.log(response.data);
				$scope.Continents  = response.data;
				/* $scope.peopleAsync = [];
				$scope.peopleAsync = response.data; */
			}
		});
	};
	
	
	
	

 
	   
	$scope.onChange = function (e, fileList) {
		var imgArray = '';
		for(var i=0; i< e.length; i++){
			if(imgArray == ''){
				imgArray =e[i].base64;
			}else{
				imgArray += ','+e[i].base64;
			}
		}
		 
		/* var authUser = '{ "authUser" : {"file":"'+ imgArray +'"}}'; */
		$scope.imagearray = imgArray;
	};
	
	
	$scope.AddAddress = function(pn){
		
		if(pn.peopleAsync == undefined || pn.peopleAsync == ''){
			return;
		}else{
			if(pn.peopleAsync.id == undefined || pn.peopleAsync.id == ''){
				var regionID = 0;
				var regionName = '';
				return;
			}else{
				var regionID = pn.peopleAsync.id;
				var regionName = pn.peopleAsync.region;
			}
			
		}
		
		if(pn.Countryname== undefined || pn.Countryname == ''){
			var subSubCategoryid = 0;
			var subSubCategoryName = 0;
			return;
			
		}else{
			if(pn.Countryname.id == undefined || pn.Countryname.id == 0){
				var CountryID= 0;
				var Countryname= '';
				return;
			}else{
				var CountryID = pn.Countryname.id ;
				var Countryname = pn.Countryname.name ;
			}
		}
		
		if(pn.city== undefined || pn.city == ''){
			var subSubCategoryid = 0;
			var subSubCategoryName = 0;
			return;
			
		}else{
			if(pn.city.id == undefined || pn.city.id == 0){
				var cityID= 0;
				var CitynameCountryCode= '';
				return;
			}else{
				var cityID = pn.city.id ;
				var CitynameCountryCode = pn.city.CountryCode ;
			}
		}
		
		if(pn.Category== undefined || pn.Category == ''){
			var subSubCategoryid = 0;
			var subSubCategoryName = 0;
			return;
			
		}else{
			if(pn.Category.id == undefined || pn.Category.id == 0){
				var CategoryID= 0;
				var CategoryName= '';
				return;
			}else{
				var CategoryID = pn.Category.id ;
				var CategoryName = pn.Category.Category ;
			}
		}
		
		if(pn.subCategory== undefined || pn.subCategory == ''){
			var subSubCategoryid = 0;
			var subSubCategoryName = 0;
			return;
			
		}else{
			if(pn.subCategory.id == undefined || pn.subCategory.id == 0){
				var subCategoryID= 0;
				var subCategoryName= '';
				return;
			}else{
				var subCategoryID = pn.subCategory.id ;
				var subCategoryName = pn.subCategory.subCategory ;
			}
		}
		
		if(pn.subSubCategory== undefined || pn.subSubCategory == ''){
			var subSubCategoryid = 0;
			var subSubCategoryName = '';
		}else{
			if(pn.subSubCategory.id == undefined || pn.subSubCategory.id == 0){
				var subSubCategoryid= 0;
				var subSubCategoryName= '';
			}else{
				var subSubCategoryid = pn.subSubCategory.id ;
				var subSubCategoryName = pn.subSubCategory.subSubCategory;
			}
		}
		subSubCategoryName = subSubCategoryName.replace(/(?:\r\n|\r|\n)/g, '<br />');
		
		
		if(pn.poiTitle == undefined || pn.poiTitle == ''){
			return false;
		}else{
			var poiTitle = pn.poiTitle;
		}
		
		if(pn.description == undefined || pn.description == ''){
			return false;
		}else if(pn.lat == undefined || pn.lat == '' || pn.lat == 0){
			return false;
		}else if(pn.long == undefined || pn.long == '' || pn.long == 0){
			return false;
		}else if(pn.address == undefined || pn.address == ''){
			return false;
		}else if(pn.phone == undefined || pn.phone == ''){
			return false;
		}else if(pn.Website == undefined || pn.Website == ''){
			return false;
		}else if(pn.otime == undefined || pn.otime == ''){
			return false;
		}else if(pn.MoreInfo == undefined || pn.MoreInfo == ''){
			return false;
		}else if(pn.Subway == undefined || pn.Subway == ''){
			return false;
		}else if(pn.tickets == undefined || pn.tickets == ''){
			return false;
		}else if(pn.Rating == undefined || pn.Rating == ''){
			return false;
		}else{
			var authUser = '{ "authUser" : {"regionID":"'+regionID+'","region":"'+regionName+'", "countryID":"'+CountryID+'","countryName":"'+Countryname+'","CityID":"'+cityID+'","CityName":"'+CitynameCountryCode+'"	,"CategoryID":"'+CategoryID+'","CategoryName":"'+CategoryName +'", "subCategoryID":"'+subCategoryID+'","subCategoryName":"'+subCategoryName+'","subSubCategoryID":"'+subSubCategoryid+'","subSubCategoryName":"'+subSubCategoryName+'","poiTitle":"'+poiTitle+'","poiDescription":"'+pn.description+'","poiLat":"'+pn.lat+'","poiLong":"'+pn.long+'","poiAddress":"'+pn.address+'","phone":"'+pn.phone+'","Website":"'+pn.Website+'","otime":"'+pn.otime+'","MoreInfo":"'+pn.MoreInfo+'","Subway":"'+pn.Subway+'","tickets":"'+pn.tickets+'","rating":"'+pn.Rating+'","file":"'+ $scope.imagearray +'"}}';
			console.log(authUser);
			
			managementService.post($rootScope.siteURL,authUser, 'poiAddfeature/uploadImg' ,  function(response) {
				if(response.status=='success'){
					console.log(response.data);
					$scope.subSubCategoryArray = '';
					$scope.subCategoryArray = '';
					$scope.CategoryArray = '';
					$scope.Cityname = '';
					$scope.Country  = '';
					pn.poiTitle = '';
					pn.description = '';
					pn.lat = '';
					pn.long = '';
					pn.address = '';
					pn.tickets = '';
					pn.Rating = '';
					$scope.imagearray = '';
					$scope.files = [];
				}
			});
		}
	};
  
	
	$scope.getPoiData();
	$scope.ContinentsShow();
	
	
	
	
	
}]);
				
			
			
app.controller('ctrl', function($scope, $http, $window, $rootScope){
	$scope.onChange = function (e, fileList) {
		
		console.log(fileList);
		 data: {file: file}
		/* alert('this is on-change handler!'); */
	};
  
	$scope.onLoad = function (e, reader, file, fileList, fileOjects, fileObj) {
		console.log(1);
		console.log(file);
		/* alert('this is handler for file reader onload event!'); */
	};
	
	var uploadedCount = 0;
	$scope.files = [];
});
		