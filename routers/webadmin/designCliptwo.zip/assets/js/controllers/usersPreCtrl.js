'use strict';
/**
 * controllers for ng-table
 * Simple table with sorting and filtering on AngularJS
 */

app.controller('userspreCtrl', ["$rootScope","$scope", "$filter", "ngTableParams","managementService", "$localStorage", function ($rootScope , $scope, $filter, ngTableParams,managementService,$localStorage) {
	
	
	
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
	$rootScope.sessionorg_id = $localStorage.org_id;
	$rootScope.sessiondefault_lang_id = $localStorage.default_lang_id;
	
    $scope.editId = -1;
	
	
	

	$scope.changeLang = function (langid) {
	
	$localStorage.default_lang_id = langid;
	
	
	$scope.language= {
				
				language : $localStorage.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			
			console.log(response.Response);
			$rootScope.translation = {
				
				response : response.Response
				
			};
	})

	}			

	if($localStorage.default_lang_id == 0){
		
	$scope.changeLang(1);		
	
	}
	else{
		
	$scope.changeLang($localStorage.default_lang_id);			
		
	}
	
	
	

	$scope.AddUser = function (pn) {
		
		pn.org_id = $rootScope.sessionorg_id;
		pn.lang_id = $rootScope.sessiondefault_lang_id;
		pn.parentid = $localStorage.user_id;	
	
	   if(pn==undefined){
		   
		   $scope.messageValid = $scope.translation.response[120].translations;
		   return false;
	   }
	   else if(pn.username==undefined || pn.username==''){
		 
		   $scope.messageValid = $scope.translation.response[121].translations;
		   return false;
	   }
	   else if(pn.password==undefined || pn.password==''){
		 
		   $scope.messageValid = "Enter Password";
		   return false;
	   }
	   else if(pn.fname==undefined || pn.fname==''){
		   
		   
		   $scope.messageValid =  $scope.translation.response[122].translations;
		   return false;
	   }
	   else if(pn.lname==undefined || pn.lname==''){
		   $scope.messageValid =  $scope.translation.response[123].translations;
		   return false;
		   
	   }
	   else if(pn.contact_no==undefined || pn.contact_no==''){
		   $scope.messageValid =  $scope.translation.response[124].translations;
		   return false;
		   
	   }
	   else if(pn.org_id==undefined || pn.org_id==''){
		   $scope.messageValid =  $scope.translation.response[125].translations;
		   return false;
		   
	   }
	   else if(pn.lang_id==undefined || pn.lang_id==''){
		   $scope.messageValid =  $scope.translation.response[126].translations;
		   return false;
		   
	   }
	   else if(pn.role_id==undefined || pn.role_id==''){
		   $scope.messageValid =  $scope.translation.response[127].translations;
		   return false;
		   
	   }
	   
	   $scope.messageValid = "";
	   
	   
		managementService.post($rootScope.siteURL, pn, 'users/addUser', function(response) {
			//console.log(response);
			$scope.defaultUserlist();
		 
		 pn.username="";
		 pn.password="";
		 pn.fname="";
		 pn.lname="";
		 pn.contact_no="";
		 pn.org_id="";
		 pn.role_id="";
		 pn.lang_id="";
		 pn.address="";
		});
		
		
    };
    
	$scope.updateUser = function (p, userinfo) {
       console.log(userinfo);
	    
	   if(p==undefined){
		   
		   $scope.messageValid1 = $scope.translation.response[120].translations;
		   return false;
	   }
	   else if(p.username==undefined || p.username==''){
		 
		   $scope.messageValid1 = $scope.translation.response[121].translations;
		   return false;
	   }
	  /* else if(p.npassword==undefined || p.npassword==''){
		 
		   $scope.messageValid1 = "Enter Password";
		   return false;
	   }*/
	   else if(userinfo.fname==undefined || userinfo.fname==''){
		   
		   
		   $scope.messageValid1 = $scope.translation.response[122].translations;
		   return false;
	   }
	   else if(userinfo.lname==undefined || userinfo.lname==''){
		   $scope.messageValid1 = $scope.translation.response[123].translations;
		   return false;
		   
	   }
	   else if(userinfo.contact_no==undefined || userinfo.contact_no==''){
		   $scope.messageValid1 = $scope.translation.response[124].translations;
		   return false;
		   
	   }
	   else if(p.org_id==undefined || p.org_id==''){
		   $scope.messageValid1 = $scope.translation.response[125].translations;
		   return false;
		   
	   }
	   else if(p.lang_id==undefined || p.lang_id==''){
		   $scope.messageValid1 = $scope.translation.response[126].translations;
		   return false;
		   
	   }
	   else if(p.role_id==undefined || p.role_id==''){
		   $scope.messageValid1 = $scope.translation.response[127].translations;
		   return false;
		   
	   }
	   
	   $scope.messageValid1 = "";
	   
	   
	   
	   
	   
	   
		$scope.updateUserdata = [];
		$scope.updateUserdata.push(p);
		$scope.updateUserdata.push(userinfo);
		
		$scope.updateUserdata[0].new_org_id = p.org_id;

		
		var langDetails = $filter('filter')($scope.data_lang.availableOptions, { name: p.name });
		$scope.updateUserdata[0].new_lang_id = p.org_id;;
		
		
		var rolesDetails = $filter('filter')($scope.data_roles.availableOptions, { role: p.role });
		$scope.updateUserdata[0].new_role_id = rolesDetails[0].role_id;
		
		
		console.log($scope.updateUserdata);
		
		
		
		managementService.post($rootScope.siteURL, $scope.updateUserdata, 'users/updateUserInfo',  function(response) {
			console.log(response);
			
		
		});
		
		
		
		 $scope.editId = -1;
    };

	
	
	
	$scope.setdeleteId = function (pid) {
		$scope.deleteId = pid;
		$scope.editId = -1;
		$scope.viewId = -1;
       
		$scope.deleteprofile = {
			userid : pid
		}
		/*
		managementService.post($rootScope.siteURL, $scope.deleteprofile, 'users/deleteprofile',  function(response) {
			console.log(response.Response);
			$scope.defaultUserlist();
		
		});	
		*/
    };
	
	
	
	$scope.deleteUser = function (p) {
	
       console.log(p);		
		managementService.post($rootScope.siteURL, p, 'users/deleteprofile',  function(response) {
			console.log(response);
			$scope.defaultUserlist();
		
		});	
		
    };
	
	
	
	

    $scope.setEditId = function (pid) {
		$scope.deleteId = -1;
        $scope.editId = pid;
		$scope.viewId = -1;
		$scope.getprofileInfo = {
			userid : pid
		}
		
		managementService.post($rootScope.siteURL, $scope.getprofileInfo, 'users/getUserinfo',  function(response) {
			console.log(response.Response);
			$scope.userinfo = {
				
				fname : response.Response[0].value,
				fname_userinfo_id : response.Response[0].userinfo_id,
				lname : response.Response[1].value,
				lname_userinfo_id : response.Response[1].userinfo_id,
				contact_no : response.Response[2].value,
				contact_no_userinfo_id : response.Response[2].userinfo_id,
				address : response.Response[3].value,
				address_userinfo_id : response.Response[3].userinfo_id
								
			}
		
		});	
    };
	
	
	
	
	 $scope.viewId = -1;

    $scope.setViewId = function (pid) {
		$scope.deleteId = -1;
        $scope.viewId = pid;
		$scope.editId = -1;
		$scope.getprofileInfo = {
			userid : pid
		}
	
	managementService.post($rootScope.siteURL, $scope.getprofileInfo, 'users/getUserinfo',  function(response) {
			console.log(response.Response);
			$scope.userinfo = {
				
				fname : response.Response[0].value,
				lname : response.Response[1].value,
				contact_no : response.Response[2].value,
				address : response.Response[3].value
								
			}
			
		});
		
		
		
    };
	
	
	
	
	$scope.defaultUserlist = function () {
        
		$scope.passdata = {
			org_id : $localStorage.org_id,
			user_id : $localStorage.user_id,
			
		};
		
		managementService.post($rootScope.siteURL, $scope.passdata, 'users/getUserListByOrg', function(response) {
			
		var data = response;
			$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});
					
		});
		
    };
	
	
	
	$scope.userlistfor_assinging = function () {
        
		$scope.passdata = {
			org_id : $localStorage.org_id,
			user_id : $localStorage.user_id,
			
		};
		
		managementService.post($rootScope.siteURL, $scope.passdata, 'users/userlistfor_assinging', function(response) {
			
		
			$scope.data_assigning_users = {
      availableOptions: response
   };
					
		});
		
    };
	
	
	
	
	
	$scope.getLanguages = function () {
        
				
		managementService.getLanguages($rootScope.siteURL,  function(response) {
			
		console.log(response);
		$scope.data_lang = {
      availableOptions: response.Response
   };
			/*$scope.tableParams = new ngTableParams({
				page: 1,
				count: 10
			}, {
				total: data.length,
				getData: function ($defer, params) {
					var orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
					$defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
				}
			});*/
					
		});
		
    };
	
	
	
	$scope.defaultOrglist = function () {
        
				
		managementService.defaultData($rootScope.siteURL,  function(response) {
			
		$scope.data_org = {
			availableOptions: response
		};

					
		});
		
    };
	
	$scope.listofroles = function() {
		
			$scope.userin= {
				
				user_id : $localStorage.user_id
			}
			if($localStorage.user_id > 0){
			managementService.post($rootScope.siteURL, $scope.userin, 'users/listOfRoles_asPerUser',  function(response) {
			console.log(response);
			if(response == ''){
						managementService.post($rootScope.siteURL, $scope.userin, 'users/listOfRoles_asPerUserDefault',  function(response) {
						console.log(response);
						
						$scope.data_roles = {
						availableOptions: response
						};

						})
			}
			else{
							$scope.data_roles = {
						availableOptions: response
					};
				
			}
			 
		
		
			
		})
		}
		
		else{
			
			managementService.listofroles($rootScope.siteURL,  function(response) {
			console.log(response);
			 $scope.data_roles = {
			availableOptions: response
		};
		})
		}
		
	};
	
	
	
	$scope.defaultUserlist();
	
	$scope.userlistfor_assinging();
	
	$scope.getLanguages();
	
	$scope.defaultOrglist();
	
	$scope.listofroles();
	
	
}]);
