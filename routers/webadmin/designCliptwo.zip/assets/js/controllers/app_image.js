angular.module('myApp', ['naif.base64'])
.controller('ctrl', function($scope, $http, $window, $rootScope){

  $scope.onChange = function (e, fileList) {
	  console.log(fileList);
    alert('this is on-change handler!');
	
  };
  
  $scope.onLoad = function (e, reader, file, fileList, fileOjects, fileObj) {
	  console.log(1);
	  console.log(file);
    alert('this is handler for file reader onload event!');
  };

  $scope.AddAddress= function(p){
	  alert(23);
	  console.log(p.length);
	  /* console.log(p[0].base64); */
  };
  
  
  var uploadedCount = 0;

  $scope.files = [];
  
})