'use strict';
/**
 * controller for Messages
 */

app.controller('rolesCtrl', ["$rootScope", "$scope", "$state", "$interval", "managementService", "$localStorage",
function($rootScope, $scope, $state, $interval, managementService, $localStorage) {
	$rootScope.user = {
					name: $localStorage.username,
					job: 'ng-Dev',
					picture: 'app/img/user/02.jpg',
					userPreviledges: $localStorage.userPreviledges,
					org : $localStorage.org
				};
				
				
				
	$scope.changeLang = function (langid) {
	
	$localStorage.default_lang_id = langid;
	
	
	$scope.language= {
				
				language : $localStorage.default_lang_id
			}
	
	managementService.post($rootScope.siteURL, $scope.language , 'getTranslations' , function(response) {
			
			console.log(response.Response);
			$rootScope.translation = {
				
				response : response.Response
				
			};
	})

	}			

	if($localStorage.default_lang_id == 0){
		
	$scope.changeLang(1);		
	
	}
	else{
		
	$scope.changeLang($localStorage.default_lang_id);			
		
	}			
				
				
				
				

	$scope.addroleoptionfield = null;
	
	$scope.listofroles = function() {
		
			$scope.userin= {
				
				user_id : $localStorage.user_id
			}
			if($localStorage.user_id > 0){
			managementService.post($rootScope.siteURL, $scope.userin, 'users/listOfRoles_asPerUser',  function(response) {
			console.log(response);
			if(response == ''){
						managementService.post($rootScope.siteURL, $scope.userin, 'users/listOfRoles_asPerUserDefault',  function(response) {
						console.log(response);
						
						$scope.data_roles = {
						availableOptions: response
						};

						})
			}
			else{
							$scope.data_roles = {
						availableOptions: response
					};
				
			}
			 
		
		
			
		})
		}
		
		else{
			
			managementService.listofroles($rootScope.siteURL,  function(response) {
			console.log(response);
			 $scope.data_roles = {
			availableOptions: response
		};
		})
		}
		
	};
	
	
	
	
	$scope.getPermissionsbyRoleId = function(role_id) {
		managementService.listofpermissionsByRoleid($rootScope.siteURL, role_id, function(response) {
			console.log(response);
			$scope.data_permissionsByRoleIdEdit = null;
			 $scope.data_permissionsByRoleId = {
			availableOptions: response
		};
		})
	};
	
	
	$scope.getPermissionsbyRoleIdEdit = function(role_id) {
		
		
		$scope.data_permissionsByRoleId = null;
		
		
		
		
		$scope.settingoption = role_id;
		var arr1 = [];
		var arr2 = [];
		var arr3 = [];
		var count = 0;
		$scope.data_permissionsByRoleId = null;
		
		
		$scope.userin= {
				
				user_id : $localStorage.user_id
			}
		if($localStorage.user_id > 0){	
		
		
		managementService.post($rootScope.siteURL, $scope.userin, 'users/listofpermissionsByUser', function(response) {
			arr1 =  response;
			managementService.listofpermissionsByRoleid($rootScope.siteURL, role_id, function(response1) {
			arr2 =  response1;
			$scope.data_permissionsByRoleId1 = {
				availableOptions: response1,
				role: role_id
			};
			 $scope.data_permissionsByRoleIdEdit = {
				availableOptions: response
			};	
		})
		})
		
		
		
		}
		else{
		managementService.listofpermissions($rootScope.siteURL,  function(response) {
			arr1 =  response;
			managementService.listofpermissionsByRoleid($rootScope.siteURL, role_id, function(response1) {
			arr2 =  response1;
			$scope.data_permissionsByRoleId1 = {
				availableOptions: response1,
				role: role_id
			};
			 $scope.data_permissionsByRoleIdEdit = {
				availableOptions: response
			};	
		})
		})
		
		}
	
	};
	
	$scope.toggleSelection = function toggleSelection(message) {
	
		if(message.checked){
			message.checked = false;
			$scope.data_permissionsByRoleId1.availableOptions.filter(function(item, i){
				if(message.privileges_id == item.privileges_id){
					$scope.data_permissionsByRoleId1.availableOptions.splice(i, 1);
				}	
			})
		} else {
			message.checked = true;
			$scope.data_permissionsByRoleId1.availableOptions.push(message);
		}
		/*console.log($scope.data_permissionsByRoleId1.availableOptions);*/
		
  };
	
	
	
	
	
	$scope.checkinfo = function(message, index) {
		$scope.data_permissionsByRoleId1.availableOptions.filter(function(item, i){
			if(message.privileges_id == item.privileges_id){
				/*console.log(i);*/
				$scope.data_permissionsByRoleIdEdit.availableOptions[index].checked = true;
			}	else {
				/*console.log("OUT");*/
			}		
		})
	};
	
	
	
	


 $scope.SavevalidateColumns = function (role_id) {

					
                         if($scope.data_permissionsByRoleId1.availableOptions.length > 0 ){
						  managementService.post($rootScope.siteURL, $scope.data_permissionsByRoleId1, 'updatePermissionListByRoleId', function(response) {
								console.log(response.Insert);
									if(response.Insert=='Successful'){
									swal($scope.translation.response[114].translations, $scope.translation.response[115].translations, "success");
									$scope.getPermissionsbyRoleId(role_id);
									}
									else{
										
										swal("Error!", "Reload the page and try again!");
										$scope.getPermissionsbyRoleId(role_id);
									}
										$scope.settingoption = null;
								})
								
						 }
                       };  


	
		$scope.addroleoption = function() {
			
				$scope.addroleoptionfield = 1;
			};	 
 	
		$scope.addNewRole = function() {
			
			$scope.dataRole = {
				role : $scope.new_role,
				createdby : $localStorage.user_id
			}
				if($scope.dataRole.role!=undefined && $scope.dataRole.role!=''){
				 managementService.post($rootScope.siteURL, $scope.dataRole, 'addNewRole', function(response) {
								console.log(response);
									if(response.Insert=='Successful'){
									swal($scope.translation.response[114].translations, $scope.translation.response[116].translations, "success");
									$scope.listofroles();
									}
									else{
										
										swal("Error!", "Reload the page and try again!");
										$scope.listofroles();
									}
										
								})
				}
				else{
					
					swal($scope.translation.response[118], $scope.translation.response[117]);
				}
				
				$scope.addroleoptionfield = null;
										$scope.dataRole = {
											role : ''
										}
			};

	
	$scope.listofroles();
	
	//$scope.listofpermissions();
	
	
	
	
}]);
app.controller('ViewMessageCrtl', ['$scope', '$stateParams',
function($scope, $stateParams) {
	function getById(arr, id) {
		for (var d = 0, len = arr.length; d < len; d += 1) {
			if (arr[d].id == id) {

				return arr[d];
			}
		}
	}


	$scope.message = getById($scope.messages, $stateParams.inboxID);

}]);
