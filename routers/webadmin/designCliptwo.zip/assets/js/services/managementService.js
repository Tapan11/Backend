'use strict';


app.factory('managementService',

['$http','$rootScope','$cookieStore',

function ($http, $rootScope,$cookieStore) {

	var service = {};
	
	service.post = function(siteURL,dataAya, api, callback){
		
		
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
				
		var res = $http.post(siteURL+api, dataAya, headers);
		res.success(function(data, status, headers, config) {
			callback(data);
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	

	}
	
	
	service.get = function(siteURL, api, callback){
		
		
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
				
		var res = $http.get(siteURL+api, headers);
		res.success(function(data, status, headers, config) {
			callback(data);
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	

	}
	
	service.defaultData = function(siteURL, callback){
		
		
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
				
		var res = $http.get(siteURL+'getOrganisations/', headers);
		res.success(function(data, status, headers, config) {
			callback(data);
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	

	}
	
	service.getLanguages = function(siteURL, callback){
		
		
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
				
		var res = $http.get(siteURL+'getLanguages/', headers);
		res.success(function(data, status, headers, config) {
			callback(data);
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	

	}
	
	
	service.updateOrg = function(siteURL,dataAya, callback){
		
		
		var dataObj = {
				org_id : dataAya.org_id,
				org_name : dataAya.org_name,
				default_lang_id : dataAya.default_lang_id,
				sponsor : dataAya.sponsor,
				};	
			
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
				
		var res = $http.post(siteURL+'updateOrganisation/', dataObj, headers);
		

	}
	
	
	
	
	
	service.addOrg = function(siteURL,dataAya, callback){
		
		
		var dataObj = {
				org_name : dataAya.org_name,
				default_lang_id : dataAya.default_lang_id,
				sponsor : dataAya.sponsor,
				};	
			
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
				
		var res = $http.post(siteURL+'addOrganisation/', dataObj, headers);
		res.success(function(data, status, headers, config) {
			callback(data);
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	

	}
	
	
	
	service.listofroles = function(siteURL, callback){
		
		
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
				
		var res = $http.get(siteURL+'getRoles/', headers);
		res.success(function(data, status, headers, config) {
			callback(data);
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	

	}
	
	
	service.listofpermissions = function(siteURL, callback){
		
		
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
				
		var res = $http.get(siteURL+'getPermissions/', headers);
		res.success(function(data, status, headers, config) {
			callback(data);
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	

	}
	
	
	
	service.listofpermissionsByRoleid = function(siteURL,role_id, callback){
		
		var dataObj = {
				role_id : role_id
				};
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
			
				
		var res = $http.post(siteURL+'getPermissionsByRoleId/', dataObj, headers);
		res.success(function(data, status, headers, config) {
			callback(data);
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	

	}
	
	

	return service;

}])



	

	

	
