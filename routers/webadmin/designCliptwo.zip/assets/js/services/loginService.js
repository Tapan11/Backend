'use strict';


app.factory('loginService',

['$http','$rootScope','$cookieStore',

function ($http, $rootScope,$cookieStore) {

	var service = {};
	
	service.defaultData = function(siteURL,dataAya, callback){
		
		
		
		var dataObj = {
				username : dataAya.username,
				password : dataAya.passwordw
				};	
			
		 var headers = {
              'Content-Type': 'application/json; charset=utf-8'
            }	
				
		var res = $http.post(siteURL+'authUser/', dataObj, headers);
		res.success(function(data, status, headers, config) {
			callback(data);
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	




/*
$http({
        method:"POST",
        url:siteURL+'getdataUser/',
        data: {username: dataAya.username,password:dataAya.password},
        headers: {
              'Content-Type': 'application/json; charset=utf-8'
            }
        }).then(function (response) {
        
        callback(response);
    },function (response) {
        callback(response);
    });		
	*/
		
		
		
	}
	
	

	return service;

}])



	

	

	
