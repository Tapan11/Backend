module.exports = {
  standardversion: ['standardversion/*'],
  rtlversion: ['rtlversion/*']
};
