module.exports = {
	standardversion: {
		options: {
			config: 'STANDARD/master/config.rb'
		}
	},
	rtlversion: {
		options: {
			config: 'RTL/master/config.rb'
		}
	}
};
