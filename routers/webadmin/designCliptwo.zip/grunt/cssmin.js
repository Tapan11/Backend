module.exports = {
  standardversion:{
  	files: {
        'standardversion/assets/css/app.min.css': ['standardversion/assets/css/app.css']
     }
  },
  rtlversion:{
    files: {
        'rtlversion/assets/css/app.min.css': ['rtlversion/assets/css/app.css']
     }
  }
};
